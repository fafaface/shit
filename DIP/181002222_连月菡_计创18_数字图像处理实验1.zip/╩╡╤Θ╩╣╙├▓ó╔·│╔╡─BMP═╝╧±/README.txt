//Author: @fafaface.github.com  
//作者: 计创18 181002222 连月菡

This folder contains two 8-bit bmp images,two 24-bit bmp images and their processing results.
这个文件夹包含了2张8位BMP图像,2张24位BMP图像,以及通过这个程序生成的结果。

Name format: No._Bitcount_Type
命名方式: 序号_位深_转换类型